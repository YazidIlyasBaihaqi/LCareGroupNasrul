<?php $__env->startSection('content'); ?>
    <div class="m-1" style="background-color:#fffafa; width:73%;">
        <h3>Form Edit Jadwal</h3>
        <?php if($errors->any()): ?>
            <div class="alert alert-danger">
                <ul>
                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li><?php echo e($error); ?></li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
            </div>
        <?php endif; ?>
        <form method="POST" action="<?php echo e(route('jadwal.update', $data->id)); ?>" id="contactForm"
            data-sb-form-api-token="API_TOKEN" enctype="multipart/form-data">
            <?php echo csrf_field(); ?>
            <?php echo method_field('PUT'); ?>
            <div class="form-floating mb-3">
                <input class="form-control" name="kode" value="<?php echo e($data->kode); ?>" id="kode" type="text"
                    placeholder="Kode Jadwal" data-sb-validations="required" />
                <label for="kode">Kode</label>
                <div class="invalid-feedback" data-sb-feedback="kode:required">kode is required.</div>
            </div>
            <div class="form-floating mb-3">
                <input class="form-control" name="kegiatan" value="<?php echo e($data->kegiatan); ?>" id="kegiatan" type="text"
                    placeholder="Kegiatan Jadwal" data-sb-validations="required" />
                <label for="kegiatan">Kegiatan</label>
                <div class="invalid-feedback" data-sb-feedback="kegiatan:required">kegiatan is required.</div>
            </div>
            <div class="form-floating mb-3">
                <input class="form-control" name="tanggal" value="" id="tanggal" type="date"
                    placeholder="Tanggal Jadwal" data-sb-validations="required" />
                <label for="tanggal">Tanggal</label>
                <div class="invalid-feedback" data-sb-feedback="tanggal:required">tanggal is required.</div>
            </div>

            <button class="btn btn-primary" name="proses" value="simpan" id="simpan" type="submit">Simpan</button>
            <button class="btn btn-info" name="unproses" value="batal" id="batal" type="reset">Batal</button>

        </form>
    </div>
    <script src="https://cdn.startbootstrap.com/sb-forms-latest.js"></script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp2\htdocs\LCareGroupNasrul-master\resources\views/jadwal/form_edit.blade.php ENDPATH**/ ?>