
<?php $__env->startSection('content'); ?>
    <div class="col-9" style="background-color:#fffafa; border-style: solid; border-color: #A7D7C5;">
        <h3>Jurnal Kesehatan</h3>
        <?php if($message = Session::get('success')): ?>
            <div class="alert alert-success">
                <p><?php echo e($message); ?></p>
            </div>
        <?php endif; ?>

        <a href="<?php echo e(route('jurkes.create')); ?>" class="btn btn-primary" title="Tambah jadwal">
            <i class="bi bi-plus"></i>
        </a>
        <div class="container mt-3">
            <table class="table table-hover datatable">
                <thead>
                    <tr>
                        <th>No</th>
                        <th>Aktivitas</th>
                        <th>Catatan</th>
                        <th>Tanggal</th>
                        <th>Aksi</th>
                    </tr>
                </thead>
            <?php
                $no = 1;
            ?>
            <?php $__currentLoopData = $datas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tbody>
                    <th><?php echo e($no); ?></th>
                    <td><?php echo e($data->aktivitas); ?></td>
                    <td><?php echo e($data->care_notes); ?></td>
                    <td><?php echo e($data->entry_date); ?></td>
                    <td>
                        <form method="POST" action="<?php echo e(route('jurkes.destroy', $data->id)); ?>">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('DELETE'); ?>
                            <a href="<?php echo e(url('/jurkes-pdf')); ?>" class="btn btn-danger" title="Export to PDF">
                                <i class="bi bi-file-earmark-pdf-fill"></i>
                            </a>
                            <a class="btn btn-warning" href="<?php echo e(route('jurkes.edit', $data->id)); ?>" title="ubah">   
                              <i class="bi bi-pencil-fill"></i>
                            </a>
                            <!-- hapus data -->
                            <button class="btn btn-danger" type="submit" title="Hapus"
                            name="proses" value="hapus"
                            onclick="return confirm('Anda Yakin Data Dihapus?')">    
                            <i class="bi bi-trash-fill"></i>
                          </button>
                    </td>
                </tbody>
            <?php    $no++    ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </table>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp2\htdocs\l_care_modified\resources\views/jurkes/index.blade.php ENDPATH**/ ?>