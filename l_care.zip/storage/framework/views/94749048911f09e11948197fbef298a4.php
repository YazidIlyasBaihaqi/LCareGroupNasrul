<div class="" style="background-color:#FFF2F2;">
    <div class="d-flex flex-wrap align-items-center justify-content-center justify-content-md-between p-3">
        <div class="col-md-3 mb-2 mb-md-0">
            <h3 style="color: 76DEB7;">Halo Lansia</h3>
        </div>

        <div class="col-md-3 text-end">
            <?php echo e($user -> user); ?>

            <a href="<?php echo e(url('logout')); ?>" class="btn btn-outline-primary me-2">Logout</a>
        </div>
    </div>
</div><?php /**PATH C:\xampp2\htdocs\l_care_modified\resources\views/layouts/header.blade.php ENDPATH**/ ?>