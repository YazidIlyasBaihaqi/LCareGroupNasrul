<?php $__env->startSection('content'); ?>
    <div class="m-1" style="background-color:#fffafa; width:73%;">
        <h3>Daftar Artikel</h3>
        <?php if($message = Session::get('success')): ?>
        <div class="alert alert-success">
        <p><?php echo e($message); ?></p>
        </div>
        <?php endif; ?>
        <br />
        </a>
        <a href="<?php echo e(route('artikel.create')); ?>" class="btn btn-primary">Tambah</a>
        <div class="container mt-3">
            <table class="table table-hover datatable">
                <thead>
                    <tr>
                        <th>No</th>
                        <th>Judul</th>
                        <th>Deskripsi</th>
                        <th>Editor</th>
                        <th>Foto</th>
                        <th>Aksi</th>
                    </tr>
                </thead>
            <?php
                $no = 1;
            ?>
            <?php $__currentLoopData = $datas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tbody>
                    <th><?php echo e($no); ?></th>
                    <td><?php echo e($item->judul); ?></td>
                    <td><?php echo e($item->deskripsi); ?></td>
                    <td><?php echo e($item->editor); ?></td>
                    <td><?php echo e($item->foto); ?></td>
                    <td>
                        <form method="POST" action="">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('DELETE'); ?>
                            <a class="btn btn-warning" href="" title="ubah">   
                              <i class="bi bi-pencil-fill"></i>
                            </a>
                            <!-- hapus data -->
                            <button class="btn btn-danger" type="submit" title="Hapus"
                            name="proses" value="hapus"
                            onclick="return confirm('Anda Yakin Data Dihapus?')">    
                            <i class="bi bi-trash-fill"></i>
                          </button>
                    </td>
                </tbody>
            <?php    $no++    ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </table>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\YAZID ILYAS\Downloads\jadwal_l-care\LCareGroupNasrul-master\resources\views/admin/artikel.blade.php ENDPATH**/ ?>