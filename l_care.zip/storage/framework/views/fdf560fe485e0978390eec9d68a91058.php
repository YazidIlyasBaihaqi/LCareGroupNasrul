
<?php $__env->startSection('content'); ?>
    
    <div class="card" style="width: 18rem;">
        <div class="card-body">
            <h5 class="card-title">Keterangan update</h5>
            <p class="card-text">Detak Jantung <?php echo e($data->detak_jantung); ?>, Tekanan Darah <?php echo e($data->tekanan_darah); ?>, Durasi Tidur <?php echo e($data->durasi_tidur); ?></p>
            <a href="<?php echo e(url('/dakes')); ?>" class="btn btn-primary">Go Back</a>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp2\htdocs\LCareGroupNasrul-master\resources\views/dakes/detail.blade.php ENDPATH**/ ?>