<?php $__env->startSection('content'); ?>
<div class="m-1" style="background-color:#fffafa; width:73%;">
 <div class="container mt-3">
    <div class="row row-cols-1 row-cols-md-2">
        <div class="col mb-4">
          <div class="card d-flex justify-content-center align-items-center">
            <img class="card-img-top" src="<?php echo e(asset('/assets/imgs/Yazid.png')); ?>" style="height:200px;width:150px;">
            <h5 class="card-title">Frontend</h5>
            <div class="card-body">
                <p class="card-text">Yazid Ilyas Baihaqi</p>
            </div>
          </div>
        </div>        
        <div class="col mb-4">
            <div class="card d-flex justify-content-center align-items-center">
              <img class="card-img-top" src="<?php echo e(asset('/assets/imgs/Rio.jpg')); ?>" style="height:200px;width:150px;">
              <h5 class="card-title">Backend</h5>
              <div class="card-body">
                  <p class="card-text">Rio Bayu</p>
              </div>
            </div>
          </div>
        <div class="col mb-4">
          <div class="card d-flex justify-content-center align-items-center">
            <img src="<?php echo e(asset('/assets/imgs/Aldi.jpg')); ?>" class="card-img-top" alt="..." style="height:200px;width:150px;">
            <h5 class="card-title">Backend</h5>
            <div class="card-body">
                <p class="card-text">M. Aldi</p>
            </div>
          </div>
        </div>
        <div class="col mb-4">
          <div class="card d-flex justify-content-center align-items-center">
            <img src="<?php echo e(asset('/assets/imgs/Eka.jpg')); ?>" class="card-img-top" alt="..." style="height:200px;width:150px;">
            <h5 class="card-title">UI dan Design</h5>
            <div class="card-body">
                <p class="card-text">Eka Rahma</p>
            </div>
          </div>
        </div>
        <div class="col mb-4">
            <div class="card d-flex justify-content-center align-items-center">
              <img src="<?php echo e(asset('/assets/imgs/Maulana.jpg')); ?>" class="card-img-top" alt="..." style="height:200px;width:150px;">
              <h5 class="card-title">UI dan Design</h5>
              <div class="card-body">
                  <p class="card-text">Maulana Aji</p>
              </div>
            </div>
          </div>
    </div>
      
        
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\LCareGroupNasrul-master\resources\views/team.blade.php ENDPATH**/ ?>