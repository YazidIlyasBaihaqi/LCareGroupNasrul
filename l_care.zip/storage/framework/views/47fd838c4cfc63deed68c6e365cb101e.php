<h3 align="center">Daftar Produk</h3>
<table border="1" align="center" cellpadding="10" cellspacing="0" width="100%">
    <thead>
        <tr>
            <th>No</th>
            
            <th>Kode</th>
            <th>Kegiatan</th>
            <th>Tanggal</th>
        </tr>
    </thead>
    <tbody>
        <?php
            $no = 1;
        ?>
        <?php $__currentLoopData = $ar_jadwal; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <th><?php echo e($no); ?></th>
                
                <td><?php echo e($data->kode); ?></td>
                <td><?php echo e($data->kegiatan); ?></td>
                <td><?php echo e($data->tanggal); ?></td>
            </tr>
            <?php $no++ ?>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
</table>
<?php /**PATH C:\xampp\htdocs\LCareGroupNasrul-master\resources\views/jadwal/jadwal_pdf.blade.php ENDPATH**/ ?>