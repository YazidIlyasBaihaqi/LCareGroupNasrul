<div class="d-flex flex-column flex-shrink-0 p-3 col-3" style="background-color: #fffafa; width:25%;">
    <ul class="nav nav-pills flex-column mb-auto">
        <li>
        <a href="<?php echo e(url('/admin')); ?>" class="nav-link mb-3 " style="color:black;">
            <svg class="bi pe-none me-2" width="16" height="16"><use xlink:href="#speedometer2"></use></svg>
            Admin
        </a>
        </li>
        <li>
        <a href="<?php echo e(url("/jadwal")); ?>" class="nav-link mb-3 " style="color:black;">
            <svg class="bi pe-none me-2" width="16" height="16"><use xlink:href="#speedometer2"></use></svg>
            User
        </a>
        </li>
        <li>
        <a href="<?php echo e(url("/dakes")); ?>" class="nav-link mb-3 " style="color:black;">
            <svg class="bi pe-none me-2" width="16" height="16"><use xlink:href="#table"></use></svg>
            Pemantauan Kesehatan
        </a>
        </li>
        <li>
        <a href="<?php echo e(url("/jurkes")); ?>" class="nav-link mb-3 " style="color:black;">
            <svg class="bi pe-none me-2" width="16" height="16"><use xlink:href="#grid"></use></svg>
            Jurnal Perawatan
        </a>
        </li>
        <li>
        <a href="<?php echo e(url("/dokumed")); ?>" class="nav-link mb-3 " style="color:black;">
            <svg class="bi pe-none me-2" width="16" height="16"><use xlink:href="#people-circle"></use></svg>
            Dokumen Medis
        </a>
        <a href="<?php echo e(url('/team')); ?>" class="nav-link mb-3 " style="color:black;">
            <svg class="bi pe-none me-2" width="16" height="16"><use xlink:href="#people-circle"></use></svg>
            Team
        </a>
        </li>
    </ul>
</div><?php /**PATH C:\Users\YAZID ILYAS\Downloads\jadwal_l-care\LCareGroupNasrul-master\resources\views/layouts/adminsidebar.blade.php ENDPATH**/ ?>