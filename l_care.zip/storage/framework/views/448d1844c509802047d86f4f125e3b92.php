<?php $__env->startSection('content'); ?>
    
    <div class="card" style="width: 18rem;">
        <div class="card-body">
            <h5 class="card-title"><?php echo e($rs->kode); ?></h5>
            <h6 class="card-subtitle mb-2 text-muted"><?php echo e($rs->tanggal); ?></h6>
            <p class="card-text">Kegiatan hari ini adalah <?php echo e($rs->kegiatan); ?></p>
            <a href="<?php echo e(url('/jadwal')); ?>" class="btn btn-primary">Go Back</a>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\LCareGroupNasrul-master\resources\views/jadwal/detail.blade.php ENDPATH**/ ?>