
<?php $__env->startSection('content'); ?>
<div class="m-1" style="background-color:#fffafa; width:73%;">
    
    <h3>Form Data Kesehatan</h3>
<?php if($errors->any()): ?>
    <div class="alert alert-danger">
        <ul>
            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li><?php echo e($error); ?></li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
    </div>
<?php endif; ?>
  <div class="container px-5 my-5">
    <form method="POST" action="<?php echo e(route('dokumed.update',$data->id)); ?>" id="dokumedForm" data-sb-form-api-token="API_TOKEN" enctype="multipart/form-data">
    <?php echo csrf_field(); ?>
    <?php echo method_field('PUT'); ?>    
        <div class="form-floating mb-3">
            <input class="form-control" name="tipe_dokumen" value="<?php echo e($data->tipe_dokumen); ?>" id="tipe_dokumen" type="text" placeholder="Tipe Dokumen" data-sb-validations="required" />
            <label for="tipe_dokumen">Tipe Dokumen</label>
            <div class="invalid-feedback" data-sb-feedback="tipe_dokumen:required">Durasi Tidur is required.</div>
        </div>
        <div class="form-floating mb-3">
            <input class="form-control" name="file_upload" value="<?php echo e($data->file_upload); ?>" id="file_upload" type="file" placeholder="file"/>
            <label for="file_upload">File Upload</label>
        </div>

        <button class="btn btn-primary" name="proses" value="simpan" id="simpan" type="submit">Simpan</button>
        <button class="btn btn-info" name="unproses" value="batal" id="batal" type="reset">Batal</button>
        <a href="<?php echo e(route('dokumed.index')); ?>" class="btn btn-light pull-right">Kembali</a>
        
    </form>
  </div>
<script src="https://cdn.startbootstrap.com/sb-forms-latest.js"></script>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp2\htdocs\LCareGroupNasrul-master\resources\views/dokumed/form_edit.blade.php ENDPATH**/ ?>