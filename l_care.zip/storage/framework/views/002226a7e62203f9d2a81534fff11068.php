<?php $__env->startSection('content'); ?>
    <div class="m-1" style="background-color:#fffafa; width:73%;">
        <div class="container mt-3">
            <table class="table table-hover datatable">
                <thead>
                    <tr>
                        <th>No</th>
                        <th>Tekanan Darah</th>
                        <th>Detak Jantung</th>
                        <th>Durasi Tidur</th>
                        <th>Aksi</th>
                    </tr>
                </thead>
            <?php
                $no = 1;
            ?>
            <?php $__currentLoopData = $datas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tbody>
                    <th><?php echo e($no); ?></th>
                    <td><?php echo e($item->tekanan_darah); ?></td>
                    <td><?php echo e($item->detak_jantung); ?></td>
                    <td><?php echo e($item->durasi_tidur); ?></td>
                    <td>
                        <form method="POST" action="">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('DELETE'); ?>
                            <a class="btn btn-warning" href="" title="ubah">   
                              <i class="bi bi-pencil-fill"></i>
                            </a>
                            <!-- hapus data -->
                            <button class="btn btn-danger" type="submit" title="Hapus"
                            name="proses" value="hapus"
                            onclick="return confirm('Anda Yakin Data Dihapus?')">    
                            <i class="bi bi-trash-fill"></i>
                          </button>
                    </td>
                </tbody>
            <?php    $no++    ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </table>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\LCareGroupNasrul-master\resources\views/dakes/index.blade.php ENDPATH**/ ?>