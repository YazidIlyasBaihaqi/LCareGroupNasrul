<?php $__env->startSection('content'); ?>
    <div class="col-9" style="background-color:#fffafa; border-style: solid; border-color: #A7D7C5;"">
        <div class="container mt-3">
            <h3>Pemantauan Kesehatan</h3>
            <?php if($message = Session::get('success')): ?>
                <div class="alert alert-success">
                    <p><?php echo e($message); ?></p>
                </div>
            <?php endif; ?>
            <div class="col-lg-12">
                <a href="<?php echo e(route('dakes.create')); ?>" class="btn btn-primary btn-rounded btn-fw">Tambah Data</a>
            </div>
            <div class="container mt-3">
                <table class="table table-hover datatable">
                    <thead>
                        <tr>
                            <th>No</th>
                            <th>Tekanan Darah</th>
                            <th>Detak Jantung</th>
                            <th>Durasi Tidur</th>
                            <th>Aksi</th>
                        </tr>
                    </thead>
                <?php
                    $no = 1;
                ?>
                <?php $__currentLoopData = $datas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tbody>
                        <th><?php echo e($no); ?></th>
                        <td><?php echo e($item->tekanan_darah); ?></td>
                        <td><?php echo e($item->detak_jantung); ?> <?php echo e($statusDetak); ?></td>
                        <td><?php echo e($item->durasi_tidur); ?> <?php echo e($statusDurasi); ?></td>
                        <td>
                            <form method="POST" action="<?php echo e(route('dakes.destroy' , $item->id)); ?>">
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('DELETE'); ?>
                                <a class="btn btn-warning" href="<?php echo e(route('dakes.edit' , $item->id)); ?>" title="Ubah">   
                                    <i class="bi bi-pencil-fill"></i>
                                </a>
                                <button class="btn btn-danger" type="submit" title="Hapus"
                                name="proses" value="hapus"
                                onclick="return confirm('Anda Yakin Data Dihapus?')">    
                                <i class="bi bi-trash-fill"></i>
                              </button>
                        </td>
                    </tbody>
                <?php    $no++    ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </table>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp2\htdocs\LCareGroupNasrul-master\resources\views/dakes/index.blade.php ENDPATH**/ ?>