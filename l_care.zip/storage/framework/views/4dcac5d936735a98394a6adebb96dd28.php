
<?php $__env->startSection('content'); ?>
    <div class="m-1" style="background-color:#fffafa; width:73%;">
        <h3>Form Jurnal Kesehatan</h3>
        <?php if($errors->any()): ?>
            <div class="alert alert-danger">
                <ul>
                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li><?php echo e($error); ?></li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
            </div>
        <?php endif; ?>
        <form method="POST" action="<?php echo e(route('jurkes.store')); ?>" id="contactForm" data-sb-form-api-token="API_TOKEN"
            enctype="multipart/form-data">
            <?php echo csrf_field(); ?>
            <div class="form-floating mb-3">
                <input class="form-control" name="entry_date" value="" id="entry_date" type="date"
                    placeholder="Tanggal Jadwal" data-sb-validations="required" />
                <label for="entry_date">Tanggal Entri</label>
                <div class="invalid-feedback" data-sb-feedback="entry_date:required">entry date is required.</div>
            </div>
            <div class="form-floating mb-3">
                <textarea class="form-control" id="exampleFormControlTextarea1" name="aktivitas" rows="5"></textarea>
                <label for="aktivitas">Aktivitas</label>
                <div class="invalid-feedback" data-sb-feedback="aktivitas:required">care notes is required.</div>
            </div>
            <div class="form-floating mb-3">
                <textarea class="form-control" id="exampleFormControlTextarea1" name="care_notes" rows="5"></textarea>
                <label for="care_notes">Care Notes</label>
                <div class="invalid-feedback" data-sb-feedback="care_notes:required">care notes is required.</div>
            </div>
            <input class="form-control invisible" name="user_id" value="<?php echo e($user->id); ?>" id="user_id" type="text"
                placeholder="Foto" data-sb-validations="required" />

            <button class="btn btn-primary" name="proses" value="simpan" id="simpan" type="submit">Simpan</button>
            <button class="btn btn-info" name="unproses" value="batal" id="batal" type="reset">Batal</button>
            <a class="btn btn-secondary" name="unproses" href="<?php echo e(route('jurkes.index')); ?>">Kembali</a>
        </form>
    </div>
    <script src="https://cdn.startbootstrap.com/sb-forms-latest.js"></script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp2\htdocs\l_care_modified\resources\views/jurkes/form.blade.php ENDPATH**/ ?>