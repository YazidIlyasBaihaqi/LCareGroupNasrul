<?php $__env->startSection('content'); ?>
    <div class="m-1" style="background-color:#fffafa; width:73%;">
        <div class="container mt-3">
            <h3>Jadwal Harian</h3>
            <?php if($message = Session::get('success')): ?>
                <div class="alert alert-success">
                    <p><?php echo e($message); ?></p>
                </div>
            <?php endif; ?>

            <a href="<?php echo e(route('jadwal.create')); ?>" class="btn btn-primary" title="Tambah jadwal">
                <i class="bi bi-plus"></i>
            </a>

            <a href="<?php echo e(url('/jadwal-pdf')); ?>" class="btn btn-danger" title="Export to PDF">
                <i class="bi bi-file-earmark-pdf-fill"></i>
            </a>

            <a href="<?php echo e(url('/jadwal-excel')); ?>" class="btn btn-success" title="Export to Excel">
                <i class="bi bi-file-earmark-excel-fill"></i>
            </a>
            <table class="table table-hover datatable">
                <thead>
                    <tr>
                        <th>No</th>
                        <th>Nama User</th>
                        <th>Kode</th>
                        <th>Kegiatan</th>
                        <th>Tanggal</th>
                    </tr>
                </thead>
                <tbody>
                    <?php
                        $no = 1;
                    ?>
                    <?php $__currentLoopData = $ar_jadwal; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <th><?php echo e($no); ?></th>
                            <td><?php echo e($data->nama); ?></td>
                            <td><?php echo e($data->kode); ?></td>
                            <td><?php echo e($data->kegiatan); ?></td>
                            <td><?php echo e($data->tanggal); ?></td>
                            <td>
                                <form method="POST" action="<?php echo e(route('jadwal.destroy', $data->id)); ?>">
                                    <?php echo csrf_field(); ?>
                                    <?php echo method_field('DELETE'); ?>
                                    <a class="btn btn-info" href="<?php echo e(route('jadwal.show', $data->id)); ?>" title="detail">
                                        <i class="bi bi-eye-fill"></i>
                                    </a>
                                    <a class="btn btn-warning" href="<?php echo e(route('jadwal.edit', $data->id)); ?>" title="ubah">
                                        <i class="bi bi-pencil-fill"></i>
                                    </a>
                                    <!-- hapus data -->
                                    <button class="btn btn-danger" type="submit" title="Hapus" name="proses"
                                        value="hapus" onclick="return confirm('Anda Yakin Data Dihapus?')">
                                        <i class="bi bi-trash-fill"></i>
                                    </button>
                                    <input type="hidden" name="idx" value="" />
                                </form>
                            </td>
                        </tr>
                        <?php $no++ ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\LCareGroupNasrul-master\resources\views/jadwal/index.blade.php ENDPATH**/ ?>